# PocketSmart AI API

- GET `/api/health`
- POST `/api/register`
- POST `/api/login`
- POST `/api/logout`
- GET `/api/session-info`
- GET `/api/session-data`
- POST `/api/generate-home`
- POST `/api/generate-party`
- POST `/api/generate-jewelry` (multipart form, optional image)
- GET `/api/history`
- GET `/api/recommendations/{id}`
