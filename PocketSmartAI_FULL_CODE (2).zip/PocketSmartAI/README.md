# PocketSmart AI

PocketSmart AI is a FastAPI + Jinja2 + Gemini budget recommendation assistant for:

- Home Interior Planner
- Party Budget Planner
- Jewelry Budget Planner
- User registration and login
- Recommendation history
- Optional jewelry outfit image upload
- Gemini AI recommendations with a local demo fallback
- Simulated marketplace catalog data

## Run in VS Code (Windows)

1. Extract the ZIP and open the **PocketSmartAI** folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Create the virtual environment:

```powershell
python -m venv .venv
```

4. Activate it:

```powershell
.venv\Scripts\activate
```

5. Install dependencies:

```powershell
pip install -r requirements.txt
```

6. Create your environment file:

```powershell
copy .env.example .env
```

7. Open `.env` and add your Gemini API key if you want live Gemini responses. Keep `.env` private.

8. Start the server:

```powershell
uvicorn app.main:app --reload
```

9. Open:

`http://127.0.0.1:8000`

API documentation:

`http://127.0.0.1:8000/docs`

## Without a Gemini API key

The application still runs. It uses the built-in demo recommendation catalog so the UI, authentication, database, history, and planner flow can be tested.

## Important security note

Do not share `.env`, database files, passwords, or API keys. The ZIP intentionally excludes `.env`, `.venv`, generated databases, Python cache files, and test cache files.

## Marketplace note

Marketplace entries are simulated demo data. They are not live prices or live availability unless real third-party APIs are added later.

## Test

Run:

```powershell
pytest
```
