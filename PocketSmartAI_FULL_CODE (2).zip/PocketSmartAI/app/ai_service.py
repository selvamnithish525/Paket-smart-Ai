import base64, json, re
from pathlib import Path
from PIL import Image
from .config import GEMINI_API_KEY, GEMINI_MODEL
from .catalog import catalog_for

def _demo(planner, data):
    budget = float(data["budget"])
    items = [x for x in catalog_for(planner) if x["price"] <= budget]
    if not items: items = catalog_for(planner)[:3]
    remaining = budget
    chosen=[]
    for item in items:
        if item["price"] <= remaining or not chosen:
            chosen.append(item); remaining=max(0, remaining-item["price"])
        if len(chosen)>=5: break
    return {"planner": planner, "source":"demo-fallback", "summary":f"Demo recommendations generated within a budget of ₹{budget:,.0f}.", "budget":budget, "estimated_total":sum(x["price"] for x in chosen), "recommendations":chosen, "tips":["Compare final prices before purchase.","Marketplace prices are demo data unless connected to live APIs."]}

def _extract_json(text):
    text=text.strip()
    text=re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I|re.S).strip()
    try: return json.loads(text)
    except json.JSONDecodeError:
        m=re.search(r"\{.*\}", text, re.S)
        if m: return json.loads(m.group(0))
    raise ValueError("Gemini did not return valid JSON")

def generate_recommendation(planner, data, image_path=None):
    if not GEMINI_API_KEY:
        return _demo(planner,data)
    try:
        from google import genai
        from google.genai import types
        client=genai.Client(api_key=GEMINI_API_KEY)
        catalog=catalog_for(planner)
        prompt=f'''You are PocketSmart AI, a budget recommendation assistant. Planner: {planner}. User data: {json.dumps(data)}. Demo marketplace catalog: {json.dumps(catalog)}. Return ONLY JSON with keys: planner, summary, budget, estimated_total, recommendations, tips. recommendations must be a list of objects with name, category, platform, price, reason. Use Indian rupees. Do not invent live availability. If catalog is insufficient, clearly say the recommendation is an example. Keep estimated_total <= budget when possible.'''
        contents=[prompt]
        if image_path:
            p=Path(image_path)
            if p.exists():
                mime={".jpg":"image/jpeg",".jpeg":"image/jpeg",".png":"image/png",".webp":"image/webp"}.get(p.suffix.lower(),"image/jpeg")
                contents.append(types.Part.from_bytes(data=p.read_bytes(), mime_type=mime))
                contents[0] += " Analyze the uploaded outfit image only for broad color/style coordination; do not identify the person."
        response=client.models.generate_content(model=GEMINI_MODEL, contents=contents)
        result=_extract_json(response.text)
        result.setdefault("planner",planner); result.setdefault("budget",float(data["budget"]))
        result.setdefault("recommendations",[]); result.setdefault("tips",[])
        result["source"]="gemini"
        return result
    except Exception as exc:
        result=_demo(planner,data)
        result["ai_error_fallback"]=type(exc).__name__
        return result
