from pathlib import Path
from tempfile import NamedTemporaryFile
from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..auth import create_access_token, get_user_id_from_request, hash_password, verify_password
from ..config import MAX_UPLOAD_MB
from ..database import get_db
from ..models import User, Recommendation
from ..schemas import RegisterRequest, LoginRequest, HomeRequest, PartyRequest, JewelryRequest
from ..services.recommendation_service import create_recommendation
router=APIRouter(prefix="/api")
def require_user(request,db):
    uid=get_user_id_from_request(request)
    if not uid: raise HTTPException(401,"Login required")
    user=db.get(User,uid)
    if not user: raise HTTPException(401,"Invalid session")
    return user
@router.get("/health")
def health(): return {"status":"ok","service":"PocketSmart AI"}
@router.post("/register")
def register(data:RegisterRequest,db:Session=Depends(get_db)):
    email=data.email.strip().lower()
    if db.scalar(select(User).where(User.email==email)): raise HTTPException(400,"Email already registered")
    user=User(name=data.name.strip(),email=email,password_hash=hash_password(data.password)); db.add(user); db.commit(); db.refresh(user)
    token=create_access_token(user.id); response=JSONResponse({"message":"Registration successful","user":{"id":user.id,"name":user.name,"email":user.email}}); response.set_cookie("access_token",token,httponly=True,samesite="lax",max_age=43200); return response
@router.post("/login")
def login(data:LoginRequest,db:Session=Depends(get_db)):
    user=db.scalar(select(User).where(User.email==data.email.strip().lower()))
    if not user or not verify_password(data.password,user.password_hash): raise HTTPException(401,"Invalid email or password")
    token=create_access_token(user.id); response=JSONResponse({"message":"Login successful","user":{"id":user.id,"name":user.name,"email":user.email}}); response.set_cookie("access_token",token,httponly=True,samesite="lax",max_age=43200); return response
@router.post("/logout")
def logout():
    response=JSONResponse({"message":"Logged out"}); response.delete_cookie("access_token"); return response
@router.get("/session-info")
def session_info(request:Request,db:Session=Depends(get_db)):
    uid=get_user_id_from_request(request)
    if not uid: return {"logged_in":False}
    user=db.get(User,uid)
    return {"logged_in":bool(user),"user_id":uid if user else None,"name":user.name if user else None}
@router.get("/session-data")
def session_data(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db); count=db.scalar(select(Recommendation).where(Recommendation.user_id==user.id).count()) if False else len(db.scalars(select(Recommendation).where(Recommendation.user_id==user.id)).all())
    return {"user":{"id":user.id,"name":user.name,"email":user.email},"recommendation_count":count}
@router.post("/generate-home")
def generate_home(data:HomeRequest,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db); return create_recommendation(db,user.id,"home",data.model_dump())
@router.post("/generate-party")
def generate_party(data:PartyRequest,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db); return create_recommendation(db,user.id,"party",data.model_dump())
@router.post("/generate-jewelry")
async def generate_jewelry(data:JewelryRequest,request:Request,db:Session=Depends(get_db),image:UploadFile|None=File(default=None)):
    user=require_user(request,db); image_path=None
    if image and image.filename:
        allowed={"image/jpeg","image/png","image/webp"}
        if image.content_type not in allowed: raise HTTPException(400,"Only JPEG, PNG or WEBP images are allowed")
        with NamedTemporaryFile(delete=False,suffix=Path(image.filename).suffix.lower()) as f:
            while True:
                chunk=image.file.read(1024*1024)
                if not chunk: break
                f.write(chunk)
                if f.tell()>MAX_UPLOAD_MB*1024*1024: raise HTTPException(413,"Image is too large")
            image_path=f.name
    try: return create_recommendation(db,user.id,"jewelry",data.model_dump(),image_path)
    finally:
        if image_path:
            try: Path(image_path).unlink(missing_ok=True)
            except OSError: pass
@router.get("/history")
def get_history(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db); rows=db.scalars(select(Recommendation).where(Recommendation.user_id==user.id).order_by(Recommendation.created_at.desc())).all()
    return {"history":[{"id":r.id,"planner":r.planner,"budget":r.budget,"created_at":r.created_at.isoformat(),"request":r.request_json,"result":r.result_json} for r in rows]}
@router.get("/recommendations/{recommendation_id}")
def recommendation_details(recommendation_id:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db); row=db.get(Recommendation,recommendation_id)
    if not row or row.user_id!=user.id: raise HTTPException(404,"Recommendation not found")
    return {"id":row.id,"planner":row.planner,"budget":row.budget,"request":row.request_json,"result":row.result_json,"created_at":row.created_at.isoformat()}
