async function logout(){await fetch('/api/logout',{method:'POST'});location='/';}
function money(v){return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(v||0)}
function showError(msg){const el=document.querySelector('#error');if(el){el.textContent=msg;el.classList.remove('hidden')}}
