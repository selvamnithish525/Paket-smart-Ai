CATALOG = {
 "home": [
  {"name":"Modern 3-Seater Sofa","category":"Furniture","platform":"Amazon","price":18999},
  {"name":"Minimalist Coffee Table","category":"Furniture","platform":"IKEA","price":6999},
  {"name":"LED Ceiling Light","category":"Lighting","platform":"Amazon","price":2499},
  {"name":"Decorative Wall Art Set","category":"Decor","platform":"Amazon","price":1999},
  {"name":"Study/Work Lamp","category":"Lighting","platform":"IKEA","price":1499},
  {"name":"Indoor Plant Pot","category":"Decor","platform":"IKEA","price":899},
 ],
 "party": [
  {"name":"Veg Party Catering Package","category":"Food","platform":"Zomato","price":650},
  {"name":"Birthday Decoration Kit","category":"Decoration","platform":"Amazon","price":2499},
  {"name":"Event Hall Demo Package","category":"Venue","platform":"OYO","price":12000},
  {"name":"Dessert & Cake Package","category":"Food","platform":"Swiggy","price":3500},
  {"name":"LED Party Lighting","category":"Decoration","platform":"Amazon","price":2999},
 ],
 "jewelry": [
  {"name":"Minimal Gold-Tone Necklace","category":"Necklace","platform":"Amazon","price":1299},
  {"name":"Pearl Drop Earrings","category":"Earrings","platform":"Flipkart","price":899},
  {"name":"Classic Bracelet","category":"Bracelet","platform":"Amazon","price":1199},
  {"name":"Elegant Statement Earrings","category":"Earrings","platform":"Flipkart","price":1599},
  {"name":"Traditional Pendant Set","category":"Set","platform":"Amazon","price":2299},
 ]
}
def catalog_for(planner): return CATALOG.get(planner, [])
